// @vitest-environment jsdom
import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import type { AltrexEvent } from '@altrex/contracts/events'
import { MobileCore } from './mobile-core'

const sse = (...chunks: string[]) => new Response(new ReadableStream({
  start(controller) {
    const enc = new TextEncoder()
    for (const c of chunks) controller.enqueue(enc.encode(`data: ${JSON.stringify({ choices: [{ delta: { content: c } }] })}\n\n`))
    controller.enqueue(enc.encode('data: [DONE]\n\n')); controller.close()
  },
}), { status: 200, headers: { 'Content-Type': 'text/event-stream' } })

const settled = (core: MobileCore) => new Promise<AltrexEvent[]>(resolve => {
  const seen: AltrexEvent[] = []
  core.onEvent(e => { seen.push(e); if (['task.completed', 'task.failed', 'task.cancelled'].includes(e.type)) resolve(seen) })
})
const start = (core: MobileCore, extra: Record<string, unknown> = {}) => core.invoke('task.start', { projectPath: '/phone', mode: 'ASK', prompt: 'hello', ...extra })

beforeEach(() => localStorage.clear())
afterEach(() => vi.unstubAllGlobals())

it('streams a real answer from the connected provider after consent', async () => {
  const calls: { url: string; body: any; auth: string }[] = []
  vi.stubGlobal('fetch', vi.fn(async (url: string, init?: RequestInit) => {
    if (String(url).endsWith('/models')) return new Response(JSON.stringify({ data: [{ id: 'm1' }] }), { status: 200 })
    calls.push({ url: String(url), body: JSON.parse(String(init?.body)), auth: String((init?.headers as any).Authorization) })
    return sse('Hel', 'lo ', 'phone')
  }))
  const core = new MobileCore()
  const providers = await core.invoke('provider.connect', { providerId: 'groq', apiKey: 'gsk_test1234' })
  expect(providers[0]).toMatchObject({ providerId: 'groq', health: 'HEALTHY', keyHint: '1234', hasCredential: true })
  const consents = await core.invoke('consent.list', {})
  await core.invoke('consent.grant', { providerId: consents[0]!.providerId, baseUrl: consents[0]!.baseUrl })
  const done = settled(core)
  await start(core, { history: [{ role: 'user', content: 'earlier' }, { role: 'assistant', content: 'reply' }] })
  const events = await done
  expect(events.filter(e => e.type === 'agent.message_delta').map(e => (e.payload as { text: string }).text).join('')).toBe('Hello phone')
  expect(events.at(-1)!.type).toBe('task.completed')
  expect(calls[0]!.url).toBe('https://api.groq.com/openai/v1/chat/completions')
  expect(calls[0]!.auth).toBe('Bearer gsk_test1234')
  expect(calls[0]!.body.stream).toBe(true)
  expect(calls[0]!.body.messages.map((m: any) => m.role)).toEqual(['system', 'user', 'assistant', 'user'])
})

it('refuses to send anything before the user allows cloud AI', async () => {
  const fetchMock = vi.fn(async () => new Response(JSON.stringify({ data: [] }), { status: 200 }))
  vi.stubGlobal('fetch', fetchMock)
  const core = new MobileCore()
  await core.invoke('provider.connect', { providerId: 'google', apiKey: 'k' })
  fetchMock.mockClear()
  const done = settled(core); await start(core); const events = await done
  expect(events.at(-1)).toMatchObject({ type: 'task.failed', payload: { code: 'CONSENT_REQUIRED' } })
  expect(fetchMock).not.toHaveBeenCalled()
})

it('tells the user when no provider is connected', async () => {
  const core = new MobileCore(); const done = settled(core); await start(core)
  expect((await done).at(-1)).toMatchObject({ type: 'task.failed', payload: { code: 'NO_PROVIDER' } })
})

it('falls back to the next provider when the first rejects the key, and reports bad keys honestly', async () => {
  vi.stubGlobal('fetch', vi.fn(async (url: string) => {
    if (String(url).endsWith('/models')) return new Response('{}', { status: 200 })
    return String(url).includes('groq') ? new Response('{}', { status: 401 }) : sse('from openrouter')
  }))
  const core = new MobileCore()
  await core.invoke('provider.connect', { providerId: 'groq', apiKey: 'bad' })
  await core.invoke('provider.connect', { providerId: 'openrouter', apiKey: 'good' })
  for (const c of await core.invoke('consent.list', {})) await core.invoke('consent.grant', { providerId: c.providerId, baseUrl: c.baseUrl })
  const done = settled(core); await start(core); const events = await done
  expect(events.map(e => e.type)).toEqual(expect.arrayContaining(['fallback.started', 'fallback.completed', 'task.completed']))
  expect((await core.invoke('provider.list', {})).find(p => p.providerId === 'groq')!.health).toBe('AUTH_ERROR')
})

it('fails clearly when the network is down, and can be cancelled', async () => {
  vi.stubGlobal('fetch', vi.fn(async (url: string, init?: RequestInit) => {
    if (String(url).endsWith('/models')) return new Response('{}', { status: 200 })
    return new Promise<Response>((_, reject) => init?.signal?.addEventListener('abort', () => reject(new DOMException('aborted', 'AbortError'))))
  }))
  const core = new MobileCore()
  await core.invoke('provider.connect', { providerId: 'groq', apiKey: 'k' })
  const c = (await core.invoke('consent.list', {}))[0]!; await core.invoke('consent.grant', { providerId: c.providerId, baseUrl: c.baseUrl })
  const done = settled(core); const { taskId } = await start(core)
  await new Promise(r => setTimeout(r, 20))
  expect(await core.invoke('task.cancel', { taskId })).toEqual({ cancelled: true })
  expect((await done).at(-1)!.type).toBe('task.cancelled')
})

it('keeps connected providers across restarts and removes them on disconnect', async () => {
  vi.stubGlobal('fetch', vi.fn(async () => new Response('{}', { status: 200 })))
  await new MobileCore().invoke('provider.connect', { providerId: 'groq', apiKey: 'abcd9999' })
  const again = new MobileCore()
  expect((await again.invoke('provider.list', {}))[0]!.keyHint).toBe('9999')
  expect(await again.invoke('provider.disconnect', { providerId: 'groq' })).toEqual([])
})

it('rejects providers a phone cannot reach and plain http custom endpoints', async () => {
  const core = new MobileCore()
  expect((await core.invokeResult('provider.connect', { providerId: 'ollama' })).ok).toBe(false)
  expect((await core.invokeResult('provider.connect', { providerId: 'custom', apiKey: 'k', baseUrl: 'http://192.168.1.5:1234/v1' })).ok).toBe(false)
})
