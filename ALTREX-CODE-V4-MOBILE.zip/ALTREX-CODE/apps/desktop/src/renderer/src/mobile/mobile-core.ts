import type { AltrexCoreBridge, CoreInvokeResult } from '@altrex/contracts/bridge'
import { isCommandName, parseCommandRequest, parseCommandResponse, type CommandName, type CommandRequest, type CommandResponse, type ParsedCommandRequest } from '@altrex/contracts/commands'
import { eventPayloadSchemas, type AltrexEvent, type EventPayload, type EventType } from '@altrex/contracts/events'
import type { CoreError, CoreErrorCode, ProjectSummary } from '@altrex/contracts/platform'
import type { ModelView, ProviderHealthState, ProviderView } from '@altrex/contracts/provider'
import type { TaskSummary } from '@altrex/contracts/tasks'
import { CONTRACT_VERSION } from '@altrex/contracts/version'
import { PROVIDER_REGISTRY, type ProviderId } from '../../../shared/provider-registry'

/**
 * `window.altrexCore` for a phone (Capacitor / browser). There is no Electron, no project folder and no
 * shell here, so this core is an honest chat core: it sends the conversation straight from the device to
 * the AI provider the user connected (their own API key) and streams the real answer back. Nothing is
 * simulated. Tasks that would need files or commands are answered as chat and say so in the prompt.
 *
 * Storage: the API key is kept in this app's private WebView storage on the device (not encrypted).
 */

type Saved = { apiKey: string; baseUrl: string; model: string }
type Health = { state: ProviderHealthState; category: string | null; message: string | null; at: string | null }

const PROVIDERS_KEY = 'altrex.mobile.providers.v1'
const CONSENT_KEY = 'altrex.mobile.consents.v1'
const PROJECT: ProjectSummary = { name: 'Phone chat', path: '/phone', branch: null, markers: [] }
const SYSTEM_PROMPT = 'You are ALTREX CODE running on a phone. You answer coding and general questions clearly and concisely. On this device you cannot open project folders, edit files or run commands, so give code and steps in your answer for the user to copy instead of claiming you changed anything.'

class CoreCommandError extends Error {
  constructor(readonly code: CoreErrorCode, message: string, readonly retryable = false) { super(message) }
}

const uuid = (): string => globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(16)}-${Math.random().toString(16).slice(2, 10)}-7000-8000-${Math.random().toString(16).slice(2, 14).padEnd(12, '0')}`
const now = () => new Date().toISOString()

function read<T>(key: string, fallback: T): T {
  try { const raw = localStorage.getItem(key); return raw ? (JSON.parse(raw) as T) : fallback } catch { return fallback }
}
function write(key: string, value: unknown): void {
  try { localStorage.setItem(key, JSON.stringify(value)) } catch { /* storage disabled: settings last for this session only */ }
}
const isProviderId = (id: string): id is ProviderId => Object.hasOwn(PROVIDER_REGISTRY, id)
/** Only providers that speak the OpenAI chat protocol over HTTPS can be reached directly from a phone. */
const reachable = (id: string) => isProviderId(id) && id !== 'ollama' && id !== 'nim-local' && id !== 'cloudflare'

function categorize(status: number): { state: ProviderHealthState; category: string } {
  if (status === 401 || status === 403) return { state: 'AUTH_ERROR', category: 'AUTH_ERROR' }
  if (status === 429) return { state: 'RATE_LIMITED', category: 'RATE_LIMITED' }
  if (status === 402) return { state: 'QUOTA_EXHAUSTED', category: 'QUOTA_EXHAUSTED' }
  if (status >= 500) return { state: 'DEGRADED', category: 'SERVER_ERROR' }
  return { state: 'DEGRADED', category: 'HTTP_ERROR' }
}

export class MobileCore implements AltrexCoreBridge {
  readonly contractVersion = CONTRACT_VERSION
  readonly streamId = uuid()
  private seq = 0
  private readonly buffer: AltrexEvent[] = []
  private readonly listeners = new Set<(event: AltrexEvent) => void>()
  private readonly tasks = new Map<string, TaskSummary>()
  private readonly history = new Map<string, AltrexEvent[]>()
  private readonly aborts = new Map<string, AbortController>()
  private readonly health = new Map<string, Health>()
  private saved: Record<string, Saved> = read(PROVIDERS_KEY, {})
  private consents: Record<string, string> = read(CONSENT_KEY, {})

  onEvent(listener: (event: AltrexEvent) => void): () => void {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  async invoke<N extends CommandName>(name: N, request: CommandRequest<N>): Promise<CommandResponse<N>> {
    const result = await this.invokeResult(name, request)
    if (!result.ok) throw new Error(`${result.error.code}: ${result.error.message}`)
    return result.value
  }

  async invokeResult<N extends CommandName>(name: N, request: CommandRequest<N>): Promise<CoreInvokeResult<N>> {
    try {
      if (!isCommandName(name)) throw new CoreCommandError('UNKNOWN_COMMAND', 'Unknown ALTREX core command.')
      let parsed: ParsedCommandRequest<N>
      try { parsed = parseCommandRequest(name, request) } catch { throw new CoreCommandError('INVALID_REQUEST', 'The request does not match the contract.') }
      return { ok: true, value: parseCommandResponse(name, await this.dispatch(name, parsed)) }
    } catch (error) {
      const coreError: CoreError = error instanceof CoreCommandError
        ? { code: error.code, message: error.message, retryable: error.retryable }
        : { code: 'INTERNAL', message: error instanceof Error ? error.message : 'ALTREX failed.', retryable: false }
      return { ok: false, error: coreError }
    }
  }

  // ---- providers --------------------------------------------------------------------------------

  private endpoint(id: string): { baseUrl: string; model: string; apiKey: string } | null {
    const entry = this.saved[id]
    if (!entry || !isProviderId(id)) return null
    const def = PROVIDER_REGISTRY[id]
    const baseUrl = (def.userBaseUrl ? entry.baseUrl : def.baseUrl).replace(/\/+$/, '')
    return baseUrl ? { baseUrl, model: entry.model || def.defaultModel, apiKey: entry.apiKey } : null
  }

  private providerViews(): ProviderView[] {
    return Object.keys(this.saved).filter(reachable).flatMap(id => {
      const ep = this.endpoint(id)
      if (!ep) return []
      const h = this.health.get(id) ?? { state: 'UNKNOWN' as const, category: null, message: null, at: null }
      return [{
        providerId: id, displayName: PROVIDER_REGISTRY[id as ProviderId].name, baseUrl: ep.baseUrl, protocol: 'openai-chat' as const, privacy: 'cloud' as const,
        health: h.state, lastErrorCategory: h.category, lastCheckedAt: h.at, model: ep.model, modelsDiscovered: 0,
        hasCredential: ep.apiKey.length > 0, keyHint: ep.apiKey ? ep.apiKey.slice(-4) : null, statusMessage: h.message,
      }]
    })
  }

  private async probe(id: string): Promise<void> {
    const ep = this.endpoint(id)
    if (!ep) return
    try {
      const response = await fetch(`${ep.baseUrl}/models`, { headers: ep.apiKey ? { Authorization: `Bearer ${ep.apiKey}` } : {}, signal: AbortSignal.timeout(15_000) })
      if (response.ok) this.setHealth(id, 'HEALTHY', null, null)
      else { const c = categorize(response.status); this.setHealth(id, c.state, c.category, `The provider answered HTTP ${response.status}.`) }
    } catch {
      this.setHealth(id, 'OFFLINE', 'NETWORK', 'Could not reach the provider. Check your internet connection.')
    }
  }

  private setHealth(id: string, state: ProviderHealthState, category: string | null, message: string | null): void {
    const ep = this.endpoint(id)
    const previous = this.health.get(id)?.state ?? 'UNKNOWN'
    this.health.set(id, { state, category, message, at: now() })
    if (ep && previous !== state) this.emit('provider.health_changed', { providerId: id, baseUrl: ep.baseUrl, state, previous, errorCategory: category }, null)
  }

  private async models(): Promise<ModelView[]> {
    const out: ModelView[] = []
    for (const id of Object.keys(this.saved).filter(reachable)) {
      const ep = this.endpoint(id)
      if (!ep) continue
      let names: string[] = []
      try {
        const response = await fetch(`${ep.baseUrl}/models`, { headers: ep.apiKey ? { Authorization: `Bearer ${ep.apiKey}` } : {}, signal: AbortSignal.timeout(15_000) })
        if (response.ok) {
          const body = await response.json() as { data?: { id?: string }[] }
          names = (body.data ?? []).map(item => item.id ?? '').filter(Boolean).slice(0, 80)
          this.setHealth(id, 'HEALTHY', null, null)
        }
      } catch { /* the default model is still listed below */ }
      if (!names.includes(ep.model)) names.unshift(ep.model)
      for (const model of names) {
        out.push({ providerId: id, baseUrl: ep.baseUrl, model, displayName: model, available: null, health: 'UNKNOWN', free: null, lastErrorCategory: null, capabilities: { chat: true, streaming: true, tools: null, streamingTools: null, vision: null, structuredOutput: null, reasoning: null, contextWindow: null, maxOutput: null } })
      }
    }
    return out
  }

  /** Providers in the order they are tried: the user's choice first, then the rest as fallbacks. */
  private candidates(modelSelection: string): { providerId: string; model: string; baseUrl: string; apiKey: string }[] {
    const ids = Object.keys(this.saved).filter(id => reachable(id) && this.endpoint(id))
    ids.sort((a, b) => Number(this.health.get(a)?.state === 'AUTH_ERROR') - Number(this.health.get(b)?.state === 'AUTH_ERROR'))
    const list = ids.map(id => ({ providerId: id, ...this.endpoint(id)! }))
    const sep = modelSelection.indexOf(':')
    if (modelSelection !== 'AUTO' && sep > 0) {
      const wanted = modelSelection.slice(0, sep), model = modelSelection.slice(sep + 1)
      const hit = list.find(item => item.providerId === wanted)
      if (hit) return [{ ...hit, model }, ...list.filter(item => item !== hit)]
    }
    return list
  }

  // ---- commands ---------------------------------------------------------------------------------

  private async dispatch(name: CommandName, request: unknown): Promise<unknown> {
    const req = request as Record<string, unknown>
    switch (name) {
      case 'events.replay': {
        const afterSeq = req.afterSeq as number
        return { streamId: this.streamId, events: this.buffer.filter(event => event.seq > afterSeq), oldestSeq: this.buffer[0]?.seq ?? null, latestSeq: this.seq, gap: false }
      }
      case 'project.open': case 'project.list': return name === 'project.open' ? PROJECT : [PROJECT]
      case 'project.permissions': return { projectPath: req.projectPath, profile: 'read_only' }
      case 'provider.list': return this.providerViews()
      case 'provider.connect': {
        const id = req.providerId as string
        if (!reachable(id)) throw new CoreCommandError('UNAVAILABLE', 'This provider cannot be reached from a phone. Use Google Gemini, Groq, OpenRouter, Cerebras, OpenAI, SambaNova, NVIDIA or a custom HTTPS endpoint.')
        const def = PROVIDER_REGISTRY[id as ProviderId]
        const apiKey = String(req.apiKey ?? '').trim(), baseUrl = String(req.baseUrl ?? '').trim()
        if (def.requiresApiKey && !apiKey) throw new CoreCommandError('INVALID_REQUEST', 'Paste your API key first.')
        if (def.userBaseUrl && !/^https:\/\//i.test(baseUrl)) throw new CoreCommandError('INVALID_REQUEST', 'A phone can only use an https:// endpoint.')
        this.saved = { ...this.saved, [id]: { apiKey, baseUrl, model: String(req.model ?? '').trim() } }
        write(PROVIDERS_KEY, this.saved)
        this.health.delete(id)
        await this.probe(id)
        return this.providerViews()
      }
      case 'provider.disconnect': {
        const id = req.providerId as string
        const { [id]: _removed, ...rest } = this.saved
        this.saved = rest; write(PROVIDERS_KEY, this.saved); this.health.delete(id)
        return this.providerViews()
      }
      case 'provider.test': await Promise.all(Object.keys(this.saved).filter(reachable).map(id => this.probe(id))); return this.providerViews()
      case 'provider.refresh': case 'model.list': return (await this.models()).filter(m => !req.providerId || m.providerId === req.providerId)
      case 'provider.openLink': {
        const id = req.providerId as string
        const def = isProviderId(id) ? PROVIDER_REGISTRY[id] : undefined
        const url = def ? (req.kind === 'docs' ? def.docsUrl : req.kind === 'apiKey' ? def.apiKeyUrl : req.kind === 'accountId' ? def.accountIdUrl ?? null : def.installUrl ?? null) : null
        if (!url || !/^https:\/\//.test(url)) return { opened: false }
        window.open(url, '_blank', 'noopener')
        return { opened: true }
      }
      case 'router.preview': {
        const list = this.candidates('AUTO')
        return { mode: req.mode ?? 'AUTO', primary: list[0] ? { providerId: list[0].providerId, model: list[0].model } : null, fallbacks: list.slice(1).map(item => ({ providerId: item.providerId, model: item.model })), reasons: list.length ? ['Your connected providers, in order.'] : ['No provider is connected yet.'], rejected: [] }
      }
      case 'permission.configure': return { interactive: true }
      case 'permission.pending': return []
      case 'permission.respond': return { accepted: false }
      case 'task.start': return { taskId: this.start(request as ParsedCommandRequest<'task.start'>) }
      case 'task.cancel': {
        const task = this.tasks.get(req.taskId as string)
        const abort = this.aborts.get(req.taskId as string)
        if (!task || task.finishedAt || !abort) return { cancelled: false }
        abort.abort(); return { cancelled: true }
      }
      case 'task.list': return [...this.tasks.values()].filter(task => (!req.sessionId || task.sessionId === req.sessionId)).reverse().slice(0, req.limit as number)
      case 'task.get': {
        const task = this.tasks.get(req.taskId as string)
        if (!task) throw new CoreCommandError('NOT_FOUND', 'Unknown task.')
        return task
      }
      case 'task.events': return { taskId: req.taskId, events: (this.history.get(req.taskId as string) ?? []).slice(-(req.limit as number)), truncated: false }
      case 'session.list': {
        const groups = new Map<string, TaskSummary[]>()
        for (const task of this.tasks.values()) if (task.sessionId) groups.set(task.sessionId, [...(groups.get(task.sessionId) ?? []), task])
        return [...groups].map(([sessionId, tasks]) => ({ sessionId, projectPath: tasks[0]!.projectPath, title: tasks[0]!.title, taskCount: tasks.length, lastState: tasks.at(-1)!.state, createdAt: tasks[0]!.createdAt, updatedAt: tasks.at(-1)!.updatedAt }))
      }
      case 'consent.list': return this.providerViews().map(p => ({ providerId: p.providerId, baseUrl: p.baseUrl, displayName: p.displayName, granted: `${p.providerId}|${p.baseUrl}` in this.consents, grantedAt: this.consents[`${p.providerId}|${p.baseUrl}`] ?? null }))
      case 'consent.grant': {
        const known = this.providerViews().some(p => p.providerId === req.providerId && p.baseUrl === req.baseUrl)
        if (known) { this.consents = { ...this.consents, [`${req.providerId}|${req.baseUrl}`]: now() }; write(CONSENT_KEY, this.consents) }
        return { granted: known }
      }
      case 'consent.revoke': {
        const key = `${req.providerId}|${req.baseUrl}`, had = key in this.consents
        const { [key]: _gone, ...rest } = this.consents
        this.consents = rest; write(CONSENT_KEY, this.consents)
        return { revoked: had }
      }
      case 'tool.list': return []
      case 'memory.list': return []
      case 'checkpoint.list': return []
      case 'checks.discover': return []
      case 'git.status': return { isRepository: false, branch: null, head: null, entries: [] }
      default: throw new CoreCommandError('UNAVAILABLE', 'This action needs a computer. It is not available on a phone.')
    }
  }

  // ---- real chat task ---------------------------------------------------------------------------

  private start(request: ParsedCommandRequest<'task.start'>): string {
    const taskId = uuid(), created = now()
    const task: TaskSummary = {
      taskId, requestId: null, sessionId: request.sessionId ?? null, mode: request.mode, intent: 'question', projectPath: request.projectPath,
      title: request.prompt.split('\n')[0]!.slice(0, 200), modelSelection: request.modelSelection, routingMode: request.routingMode ?? null,
      engine: null, state: 'RECEIVED', createdAt: created, updatedAt: created, finishedAt: null, checkpointIds: [], changedFiles: [], agents: [], outcome: null, eventsTruncated: false, verdict: null,
    }
    this.tasks.set(taskId, task)
    this.emit('task.created', { state: 'RECEIVED', mode: task.mode, intent: 'question', projectPath: task.projectPath, title: task.title, modelSelection: task.modelSelection }, taskId)
    const abort = new AbortController()
    this.aborts.set(taskId, abort)
    void this.run(task, request, abort).finally(() => this.aborts.delete(taskId))
    return taskId
  }

  private async run(task: TaskSummary, request: ParsedCommandRequest<'task.start'>, abort: AbortController): Promise<void> {
    const fail = (message: string, code: string | null) => {
      task.outcome = { reason: message, code }
      this.transition(task, 'FAILED')
      this.emit('task.failed', { message, code }, task.taskId)
    }
    const list = this.candidates(request.modelSelection)
    if (list.length === 0) return fail('No AI provider is connected. Open Settings, add a provider (Google Gemini and Groq have free keys) and try again.', 'NO_PROVIDER')
    const needConsent = list.filter(item => !(`${item.providerId}|${item.baseUrl}` in this.consents))
    if (needConsent.length === list.length) return fail('Allow cloud AI before sending your message to a provider.', 'CONSENT_REQUIRED')
    const allowed = list.filter(item => `${item.providerId}|${item.baseUrl}` in this.consents)

    this.transition(task, 'ANSWERING')
    const messages = [{ role: 'system', content: SYSTEM_PROMPT }, ...request.history.map(m => ({ role: m.role, content: m.content })), { role: 'user', content: request.prompt }]
    let previous: { providerId: string; model: string } | null = null
    let lastError = 'The AI provider did not answer.'
    for (const candidate of allowed) {
      const to = { providerId: candidate.providerId, model: candidate.model }
      if (previous) this.emit('fallback.started', { role: 'Ask', from: previous, to, reason: lastError }, task.taskId)
      this.emit('model.selected', { provider: PROVIDER_REGISTRY[candidate.providerId as ProviderId].name, model: candidate.model, reasons: previous ? ['Fallback after an error.'] : ['Your connected provider.'], providerId: candidate.providerId, role: 'Ask', mode: request.routingMode ?? 'AUTO' }, task.taskId)
      let received = false
      try {
        const response = await fetch(`${candidate.baseUrl}/chat/completions`, {
          method: 'POST', signal: abort.signal,
          headers: { 'Content-Type': 'application/json', ...(candidate.apiKey ? { Authorization: `Bearer ${candidate.apiKey}` } : {}) },
          body: JSON.stringify({ model: candidate.model, messages, stream: true }),
        })
        if (!response.ok) {
          const c = categorize(response.status)
          this.setHealth(candidate.providerId, c.state, c.category, `The provider answered HTTP ${response.status}.`)
          lastError = `${PROVIDER_REGISTRY[candidate.providerId as ProviderId].name}: ${c.category}`
          previous = to
          continue
        }
        if (!response.body) throw new Error('empty body')
        const reader = response.body.getReader(), decoder = new TextDecoder()
        let pending = ''
        for (;;) {
          const { done, value } = await reader.read()
          if (done) break
          pending += decoder.decode(value, { stream: true })
          const lines = pending.split('\n'); pending = lines.pop() ?? ''
          for (const raw of lines) {
            const line = raw.trim()
            if (!line.startsWith('data:')) continue
            const data = line.slice(5).trim()
            if (!data || data === '[DONE]') continue
            try {
              const delta = (JSON.parse(data) as { choices?: { delta?: { content?: string | null } }[] }).choices?.[0]?.delta?.content
              if (delta) { received = true; this.emit('agent.message_delta', { text: delta }, task.taskId) }
            } catch { /* ignore keep-alive or partial frames */ }
          }
        }
        if (!received) { lastError = 'The provider returned an empty answer.'; previous = to; continue }
        this.setHealth(candidate.providerId, 'HEALTHY', null, null)
        if (previous) this.emit('fallback.completed', { role: 'Ask', from: previous, to }, task.taskId)
        this.transition(task, 'COMPLETED'); task.finishedAt = now()
        this.emit('task.completed', {}, task.taskId)
        return
      } catch (error) {
        if (abort.signal.aborted) {
          this.transition(task, 'CANCELLED'); task.finishedAt = now()
          this.emit('task.cancelled', {}, task.taskId)
          return
        }
        if (received) return fail('The connection dropped while the answer was streaming.', 'PROVIDER_ERROR')
        this.setHealth(candidate.providerId, 'OFFLINE', 'NETWORK', 'Could not reach the provider.')
        lastError = error instanceof Error ? `${PROVIDER_REGISTRY[candidate.providerId as ProviderId].name}: network error` : 'network error'
        previous = to
      }
    }
    if (previous) this.emit('fallback.failed', { role: 'Ask', from: previous, reason: lastError, attempted: allowed.length }, task.taskId)
    fail(`${lastError}. Check your API key and internet connection in Settings.`, 'PROVIDER_ERROR')
  }

  private transition(task: TaskSummary, to: TaskSummary['state']): void {
    if (task.state === to) return
    this.emit('task.state_changed', { from: task.state, to }, task.taskId)
    task.state = to; task.updatedAt = now()
    if (to === 'FAILED') task.finishedAt = task.updatedAt
  }

  private emit<T extends EventType>(type: T, payload: EventPayload<T>, taskId: string | null): void {
    const event = { v: CONTRACT_VERSION, streamId: this.streamId, seq: ++this.seq, id: uuid(), ts: now(), taskId, type, payload: eventPayloadSchemas[type].parse(payload) } as AltrexEvent
    this.buffer.push(event)
    if (this.buffer.length > 5000) this.buffer.shift()
    if (taskId) this.history.set(taskId, [...(this.history.get(taskId) ?? []), event])
    for (const listener of this.listeners) { try { listener(event) } catch { /* a broken listener never breaks the core */ } }
  }
}
