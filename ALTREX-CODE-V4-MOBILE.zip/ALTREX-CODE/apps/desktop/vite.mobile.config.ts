import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig, type Plugin } from 'vite'
import { resolve } from 'node:path'

/**
 * Production build of the same React UI for the Android app (Capacitor WebView).
 * The desktop CSP only allows loopback connections because Electron's main process talks to the AI
 * providers. On a phone the WebView itself calls the provider over HTTPS, so connect-src gains `https:`.
 */
const phoneCsp = (): Plugin => ({
  name: 'altrex-phone-csp',
  transformIndexHtml: html => html.replace("connect-src 'self' ws://127.0.0.1:* http://127.0.0.1:*", "connect-src 'self' https:"),
})

export default defineConfig({
  root: resolve('src/renderer'),
  base: './',
  plugins: [react(), tailwindcss(), phoneCsp()],
  build: { outDir: resolve('../mobile/www'), emptyOutDir: true },
})
